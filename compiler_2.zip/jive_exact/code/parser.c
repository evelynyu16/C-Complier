#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

// ===== AST definitions =====
typedef enum AST_Kind {
    AST_NONE,
    AST_PROGRAM,
    AST_FN,
    AST_TYPE,
    AST_RETURN,
    AST_INTEGER,
} AST_Kind;

const char *ast_kind_as_cstr(AST_Kind kind)
{
    switch (kind) {
        case AST_NONE:    return "NONE (ERROR!)";
        case AST_PROGRAM: return "PROGRAM";
        case AST_FN:      return "FN";
        case AST_TYPE:    return "TYPE";
        case AST_RETURN:  return "RETURN";
        case AST_INTEGER: return "INTEGER";
        default:          return "UNKNOWN (ERROR!)";
    }
}

typedef struct AST_Node AST_Node;

typedef struct AST_List {
    long count;
    AST_Node *first;
    AST_Node *last;
} AST_List;

typedef struct AST_Fn_Data {
    String name;
    AST_List parameters; // (unused for now)
    Type return_type;
    AST_List body;
} AST_Fn_Data;

struct AST_Node {
    AST_Kind kind;
    AST_Node *prev;
    AST_Node *next;
    union {
        AST_List    program;
        AST_Fn_Data fn;
        Type        type;
        AST_Node   *ret_expr;
        long        int_value;
    };
};

typedef struct Parser {
    Token_Array tokens;
    long tok_index;
    bool has_error;
} Parser;

static AST_Node *make_ast_node(AST_Kind kind)
{
    AST_Node *result = (AST_Node*)calloc(1, sizeof(AST_Node));
    result->kind = kind;
    return result;
}

static void report_error(Parser *parser, Token *tok, const char *message)
{
    print_loc(tok->loc);
    printf(": %s", message);
    parser->has_error = true;
}

static Token *peek_token(Parser *parser, int offset)
{
    long index = parser->tok_index + offset;
    if (index >= parser->tokens.count) {
        Token *EOF_Token = &parser->tokens.items[parser->tokens.count - 1];
        return EOF_Token;
    }
    return &parser->tokens.items[index];
}

static void advance(Parser *parser) { if (parser->tok_index < parser->tokens.count) ++parser->tok_index; }

static Token *expect_token(Parser *parser, Token_Kind expected_kind)
{
    Token *actual = peek_token(parser, 0);
    if (actual->kind != expected_kind) {
        report_error(parser, actual, "ERROR: Unexpected token\n");
        printf("ERROR: Expected "); print_token_kind(expected_kind);
        printf(", got "); print_token(actual); printf("\n");
        return actual;
    }
    ++parser->tok_index;
    return actual;
}

static Token *expect_keyword(Parser *parser, Keyword expected_keyword)
{
    Token *actual = expect_token(parser, TOKEN_KEYWORD);
    if (parser->has_error) return actual;
    if (actual->keyword != expected_keyword) {
        report_error(parser, actual, "ERROR: Unexpected keyword\n");
        printf("Expected keyword %.*s, got ", PRINT_STRING(keyword_names[expected_keyword]));
        print_token(actual);
        printf("\n");
    }
    return actual;
}

static void ast_list_append(AST_List *list, AST_Node *node)
{
    if (!node) return;
    node->prev = list->last;
    node->next = NULL;
    if (list->last) list->last->next = node;
    else list->first = node;
    list->last = node;
    list->count++;
}

// Forward decls
static AST_List parse_block(Parser *parser);

static AST_Node *parse_statement(Parser *parser)
{
    Token *tok = peek_token(parser, 0);
    if (tok->kind == TOKEN_KEYWORD && tok->keyword == KEYWORD_return) {
        advance(parser); // consume 'return'
        AST_Node *ret = make_ast_node(AST_RETURN);

        // Only integer literal expressions supported
        Token *expr = expect_token(parser, TOKEN_INTEGER);
        if (!parser->has_error) {
            AST_Node *ival = make_ast_node(AST_INTEGER);
            ival->int_value = expr->int_value;
            ret->ret_expr = ival;
        }

        // optional ';'
        Token *maybe = peek_token(parser, 0);
        if (maybe->kind == ';') advance(parser);

        return ret;
    }

    // If we get here, it's an error for this simplified language
    report_error(parser, tok, "ERROR: Expected a statement (only 'return <int>;' is supported)\n");
    return make_ast_node(AST_NONE);
}

static AST_List parse_block(Parser *parser)
{
    AST_List result = (AST_List){0};
    expect_token(parser, '{');
    if (parser->has_error) return result;

    Token *tok = peek_token(parser, 0);
    while (tok->kind != '}' && tok->kind != TOKEN_EOF) {
        AST_Node *stmt = parse_statement(parser);
        ast_list_append(&result, stmt);
        if (parser->has_error) break;
        tok = peek_token(parser, 0);
    }
    expect_token(parser, '}');
    return result;
}

static AST_Node *parse_fn_def(Parser *parser)
{
    AST_Node *result = make_ast_node(AST_FN);

    expect_keyword(parser, KEYWORD_fn);
    if (parser->has_error) return result;

    Token *name = expect_token(parser, TOKEN_IDENT);
    if (parser->has_error) return result;
    result->fn.name = name->ident;

    expect_token(parser, '(');
    if (parser->has_error) return result;

    // No parameters in this stage
    expect_token(parser, ')');
    if (parser->has_error) return result;

    // Optional -> type
    Type return_type = TYPE_NONE;
    Token *maybe_arrow = peek_token(parser, 0);
    if (maybe_arrow->kind == TOKEN_ARROW) {
        advance(parser); // consume '->'
        Token *ret_type_token = expect_token(parser, TOKEN_TYPE);
        if (parser->has_error) return result;
        return_type = ret_type_token->type;
    }
    result->fn.return_type = return_type;

    // Body
    result->fn.body = parse_block(parser);
    return result;
}

// Parse result
typedef struct Parse_Result {
    AST_Node *ast;
    bool success;
} Parse_Result;

Parse_Result parse_program(Token_Array tokens)
{
    Parse_Result result = { .ast = make_ast_node(AST_PROGRAM), .success = true };
    Parser parser = { .tokens = tokens, .tok_index = 0, .has_error = false };

    while (1) {
        Token *tok = peek_token(&parser, 0);
        if (tok->kind == TOKEN_EOF) break;
        if (tok->kind == TOKEN_KEYWORD && tok->keyword == KEYWORD_fn) {
            AST_Node *fn_def = parse_fn_def(&parser);
            ast_list_append(&result.ast->program, fn_def);
        } else {
            report_error(&parser, tok, "ERROR: Expected 'fn' at the start of a function definition\n");
            break;
        }
    }
    result.success = !parser.has_error;
    return result;
}

static void print_ast_with_indent(AST_Node *node, int depth)
{
    switch (node->kind) {
        case AST_NONE:    printf("%*sAST_NONE (ERROR!)\n", 2*depth, ""); break;
        case AST_PROGRAM: {
            printf("%*sprogram\n", 2*depth, "");
            for (AST_Node *fn_node = node->program.first; fn_node != NULL; fn_node = fn_node->next) {
                print_ast_with_indent(fn_node, depth + 1);
            }
        } break;
        case AST_FN: {
            printf("%*sfn %.*s(\n", 2*depth, "", PRINT_STRING(node->fn.name));
            printf("%*s)\n", 2*depth, "");
            for (AST_Node *body_node = node->fn.body.first; body_node != NULL; body_node = body_node->next) {
                print_ast_with_indent(body_node, depth + 1);
            }
        } break;
        case AST_TYPE:    printf("%*stype %.*s\n", 2*depth, "", PRINT_STRING(type_names[node->type])); break;
        case AST_RETURN:  printf("%*sreturn\n", 2*depth, ""); if (node->ret_expr) print_ast_with_indent(node->ret_expr, depth + 1); break;
        case AST_INTEGER: printf("%*sinteger %ld\n", 2*depth, "", node->int_value); break;
        default:          printf("%*sUNHANDLED AST_KIND: %d\n", 2*depth, "", node->kind); break;
    }
}

void print_ast(AST_Node *node) { print_ast_with_indent(node, 0); }
