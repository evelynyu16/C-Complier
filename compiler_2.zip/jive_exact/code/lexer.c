#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>

// ===== Shared string type (from string.c) =====
// (String type & helpers come from string.c; included by unity build)

// ===== Source location =====
typedef struct Src_Loc {
    int line;
    int col;
    const char *file;
} Src_Loc;

void print_loc(Src_Loc loc) {
    printf("%s:%d:%d", loc.file ? loc.file : "<input>", loc.line, loc.col);
}

// ===== Token definitions =====
typedef enum {
    // ASCII punctuation tokens use their character code directly, e.g. '(' or '{'
    TOKEN_EOF = 0,
    TOKEN_KEYWORD = 256,
    TOKEN_IDENT,
    TOKEN_INTEGER,
    TOKEN_TYPE,
    TOKEN_ARROW, // '->'
} Token_Kind;

typedef enum {
    KEYWORD_NONE = 0,
    KEYWORD_fn,
    KEYWORD_return,
} Keyword;

typedef enum {
    TYPE_NONE = 0,
    TYPE_int,
} Type;

// Names for pretty printing
String keyword_names[] = {
    [KEYWORD_NONE] = str_lit(""),
    [KEYWORD_fn]   = str_lit("fn"),
    [KEYWORD_return] = str_lit("return"),
};

// Provide a stable index 0 too
static String _empty_str = { "", 0 };

String type_names[] = {
    [TYPE_NONE] = str_lit("none"),
    [TYPE_int]  = str_lit("int"),
};

typedef struct Token {
    Token_Kind kind;
    Src_Loc loc;
    union {
        Keyword keyword;
        String  ident;
        long    int_value;
        Type    type;
    };
} Token;

typedef struct {
    Token *items;
    long count;
    long capacity;
} Token_Array;

static void token_array_push(Token_Array *arr, Token tok) {
    if (arr->count + 1 > arr->capacity) {
        arr->capacity = arr->capacity ? arr->capacity * 2 : 64;
        arr->items = (Token*)realloc(arr->items, sizeof(Token) * arr->capacity);
    }
    arr->items[arr->count++] = tok;
}

static void print_token_kind(Token_Kind k) {
    if (k < 256 && isprint(k)) { printf("'%c'", (char)k); return; }
    switch (k) {
        case TOKEN_EOF: printf("EOF"); break;
        case TOKEN_KEYWORD: printf("KEYWORD"); break;
        case TOKEN_IDENT: printf("IDENT"); break;
        case TOKEN_INTEGER: printf("INTEGER"); break;
        case TOKEN_TYPE: printf("TYPE"); break;
        case TOKEN_ARROW: printf("ARROW"); break;
        default: printf("UNKNOWN(%d)", k); break;
    }
}

void print_token(Token *t) {
    switch (t->kind) {
        case TOKEN_KEYWORD: printf("KEYWORD %.*s", PRINT_STRING(keyword_names[t->keyword])); break;
        case TOKEN_IDENT:   printf("IDENT %.*s", PRINT_STRING(t->ident)); break;
        case TOKEN_INTEGER: printf("INTEGER %ld", t->int_value); break;
        case TOKEN_TYPE:    printf("TYPE %.*s", PRINT_STRING(type_names[t->type])); break;
        case TOKEN_ARROW:   printf("ARROW"); break;
        default:
            if (t->kind < 256 && isprint(t->kind)) printf("'%c'", (char)t->kind);
            else print_token_kind(t->kind);
            break;
    }
}

void print_token_array(Token_Array arr) {
    for (long i = 0; i < arr.count; ++i) {
        printf("[%3ld] ", i);
        print_loc(arr.items[i].loc);
        printf(": ");
        print_token(&arr.items[i]);
        printf("\n");
    }
}

static bool is_ident_start(int c) { return isalpha(c) || c == '_'; }
static bool is_ident_char(int c) { return isalnum(c) || c == '_'; }

static int peekc(const char *s, long i) { return s[i]; }

static bool match_arrow(const char *s, long i) {
    return s[i] == '-' && s[i+1] == '>';
}

static Keyword keyword_from_ident(String s) {
    if (s.count == 2 && strncmp(s.data, "fn", 2) == 0) return KEYWORD_fn;
    if (s.count == 6 && strncmp(s.data, "return", 6) == 0) return KEYWORD_return;
    return KEYWORD_NONE;
}

static bool is_type_ident(String s, Type *out) {
    if (s.count == 3 && strncmp(s.data, "int", 3) == 0) { *out = TYPE_int; return true; }
    return false;
}

static char *slurp_file(const char *path, long *out_size) {
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    fseek(f, 0, SEEK_END);
    long n = ftell(f);
    fseek(f, 0, SEEK_SET);
    char *buf = (char*)malloc(n + 1);
    fread(buf, 1, n, f);
    buf[n] = 0;
    fclose(f);
    if (out_size) *out_size = n;
    return buf;
}

Token_Array lex_file(const char *path) {
    Token_Array out = {0};
    long size = 0;
    char *src = slurp_file(path, &size);
    if (!src) { fprintf(stderr, "ERROR: Could not open input file %s\n", path); exit(1); }
    int line = 1, col = 1;

    for (long i = 0; i <= size; ) {
        int c = src[i];
        Src_Loc loc = { line, col, path };

        // EOF
        if (c == 0) {
            Token t = { .kind = TOKEN_EOF, .loc = loc };
            token_array_push(&out, t);
            break;
        }

        // whitespace
        if (c == ' ' || c == '\t' || c == '\r') { ++i; ++col; continue; }
        if (c == '\n') { ++i; ++line; col = 1; continue; }

        // comments (// ...)
        if (c == '/' && src[i+1] == '/') {
            i += 2; col += 2;
            while (src[i] && src[i] != '\n') { ++i; ++col; }
            continue;
        }

        // arrow ->
        if (match_arrow(src, i)) {
            Token t = { .kind = TOKEN_ARROW, .loc = loc };
            token_array_push(&out, t);
            i += 2; col += 2; continue;
        }

        // punctuation single-char
        if (c=='(' || c==')' || c=='{' || c=='}' || c==';') {
            Token t = { .kind = (Token_Kind)c, .loc = loc };
            token_array_push(&out, t);
            ++i; ++col; continue;
        }

        // number literal
        if (isdigit(c)) {
            long val = 0;
            while (isdigit(src[i])) { val = val*10 + (src[i]-'0'); ++i; ++col; }
            Token t = { .kind = TOKEN_INTEGER, .loc = loc };
            t.int_value = val;
            token_array_push(&out, t);
            continue;
        }

        // identifier / keyword / type
        if (is_ident_start(c)) {
            long start = i;
            while (is_ident_char(src[i])) { ++i; ++col; }
            String s = { src + start, i - start };
            Keyword kw = keyword_from_ident(s);
            if (kw != KEYWORD_NONE) {
                Token t = { .kind = TOKEN_KEYWORD, .loc = loc };
                t.keyword = kw;
                token_array_push(&out, t);
            } else {
                Type ty = TYPE_NONE;
                if (is_type_ident(s, &ty)) {
                    Token t = { .kind = TOKEN_TYPE, .loc = loc };
                    t.type = ty;
                    token_array_push(&out, t);
                } else {
                    Token t = { .kind = TOKEN_IDENT, .loc = loc };
                    t.ident = s;
                    token_array_push(&out, t);
                }
            }
            continue;
        }

        // unknown
        fprintf(stderr, "Lex ERROR at "); print_loc(loc); fprintf(stderr, ": unexpected char '%c' (0x%02X)\n", c, c);
        exit(1);
    }
    return out;
}
