#include <stdio.h>
#include <stdbool.h>

// Generate _start and exit sequence
void generate_preamble(FILE *out_file)
{
    fprintf(out_file, "global _start\n");
    fprintf(out_file, "\n");
    fprintf(out_file, "_start:\n");
    fprintf(out_file, "    call main\n");
    fprintf(out_file, "    mov rdi, rax\n");
    fprintf(out_file, "    mov rax, 60\n");
    fprintf(out_file, "    syscall\n");
    fprintf(out_file, "\n");
}

static bool generate_asm_for_stmt(AST_Node *stmt, FILE *out_file)
{
    switch (stmt->kind) {
        case AST_RETURN:
            if (!stmt->ret_expr || stmt->ret_expr->kind != AST_INTEGER) {
                printf("ERROR: Only 'return <int>' is supported for now.\n");
                return false;
            }
            fprintf(out_file, "    mov rax, %ld\n", stmt->ret_expr->int_value);
            fprintf(out_file, "    ret\n");
            return true;
        default:
            printf("ERROR: Unsupported statement kind in codegen.\n");
            return false;
    }
}

// Generate code for a single function (label + body)
bool generate_asm_for_fn(AST_Node *fn_node, FILE *out_file)
{
    if (fn_node->kind != AST_FN) {
        printf("ERROR: Expected FN node in generate_asm_for_fn, got %s\n", ast_kind_as_cstr(fn_node->kind));
        return false;
    }
    // Function label
    fprintf(out_file, "%.*s:\n", PRINT_STRING(fn_node->fn.name));

    // Iterate over body statements (only return for now)
    for (AST_Node *n = fn_node->fn.body.first; n != NULL; n = n->next) {
        if (!generate_asm_for_stmt(n, out_file)) return false;
    }
    return true;
}

bool generate_asm(AST_Node *ast, FILE *out_file)
{
    if (ast == NULL || ast->kind != AST_PROGRAM) {
        printf("ERROR: Root AST node was not PROGRAM. Got kind %s\n", ast ? ast_kind_as_cstr(ast->kind) : "NULL");
        return false;
    }
    generate_preamble(out_file);
    for (AST_Node *fn_node = ast->program.first; fn_node != NULL; fn_node = fn_node->next) {
        if (!generate_asm_for_fn(fn_node, out_file)) return false;
    }
    return true;
}
