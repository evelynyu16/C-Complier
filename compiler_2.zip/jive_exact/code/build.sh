#!/bin/bash
set -euo pipefail

# build dir
mkdir -p "$(dirname "$0")/../build"
pushd "$(dirname "$0")/../build" >/dev/null

gcc -Wall -Wextra -ggdb ../code/main.c -o jive
ret_val=$?
if [ $ret_val -ne 0 ]; then
    echo "ERROR: Failed to build"
    exit $ret_val
fi

echo "Build success!"

echo "=== TEST ON SIMPLE.JIVE ==="
./jive ../jive_programs/simple.jive -o simple.asm

echo "Wrote assembly to build/simple.asm"
popd >/dev/null
