#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>

// Unity build: pull in the individual C files
#include "string.c"
#include "lexer.c"
#include "parser.c"
#include "codegen.c"

typedef struct Options
{
    const char *out_file_name;
    const char *in_file_name;
} Options;

void print_usage(const char *program_name)
{
    printf("Usage: %s input_file.jive [-o output_file.asm]\n", program_name);
}

int main(int arg_count, const char **args)
{
    // Parse command line arguments
    Options options = {
        .out_file_name = "out.asm",
        .in_file_name  = NULL,
    };
    int arg_index = 0;
    const char *program_name = args[arg_index++];
    while (arg_index < arg_count)
    {
        const char *arg = args[arg_index++];
        if (strcmp(arg, "-o") == 0)
        {
            if (arg_index < arg_count) options.out_file_name = args[arg_index++];
            else { printf("ERROR: Missing output file name after -o flag.\n"); return 1; }
        }
        else if (options.in_file_name == NULL) options.in_file_name = arg;
        else printf("WARNING: Unrecognized command line argument %s\n", arg);
    }
    if (options.in_file_name == NULL) { printf("ERROR: No input file supplied.\n"); print_usage(program_name); return 1; }

    // 1) Lex
    Token_Array tokens = lex_file(options.in_file_name);
    bool test_lexer = true;
    if (test_lexer) { printf("Lexer output:\n"); print_token_array(tokens); }

    // 2) Parse
    Parse_Result parse_result = parse_program(tokens);
    if (!parse_result.success) { printf("ERROR: Failed to parse.\n"); return 1; }
    bool test_parser = true;
    if (test_parser) { printf("Parser output:\n"); print_ast(parse_result.ast); }

    // 3) Codegen
    FILE *out_file = fopen(options.out_file_name, "w");
    if (!out_file) { printf("ERROR: Could not open %s for writing.\n", options.out_file_name); return 1; }
    if (!generate_asm(parse_result.ast, out_file)) { fclose(out_file); return 1; }
    fclose(out_file);
    return 0;
}
